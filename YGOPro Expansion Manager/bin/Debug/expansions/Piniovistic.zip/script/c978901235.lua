--Piniovistic Ice Majesty
function c978901235.initial_effect(c)
	--Rune Summon
	c:EnableReviveLimit()
	aux.AddRuneProcedure(c,nil,1,1,aux.FilterBoolFunction(Card.IsSetCard,0xfdf),1,1)
	--equip
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(40884383,0))
	e1:SetCategory(CATEGORY_EQUIP+CATEGORY_SEARCH)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetTarget(c978901235.eqtg)
	e1:SetOperation(c978901235.eqop)
	c:RegisterEffect(e1)
	--Act on Set Turn
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetCode(EFFECT_TRAP_ACT_IN_SET_TURN)
	e2:SetRange(LOCATION_MZONE)
	e2:SetTargetRange(LOCATION_SZONE,0)
	c:RegisterEffect(e2)
end
function c978901235.eqfilter(c,ec)
	return c:IsSetCard(0xfdf) and c:IsType(TYPE_SPELL+TYPE_TRAP)
end
function c978901235.eqtg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsFaceup() end
	if chk==0 then return Duel.GetLocationCount(e:GetHandlerPlayer(),LOCATION_SZONE)>0
		and Duel.IsExistingTarget(Card.IsFaceup,e:GetHandlerPlayer(),LOCATION_MZONE,LOCATION_MZONE,1,nil) 
		and Duel.IsExistingTarget(c978901235.eqfilter,e:GetHandlerPlayer(),LOCATION_DECK,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_EQUIP)
	local g=Duel.SelectTarget(tp,Card.IsFaceup,tp,LOCATION_MZONE,LOCATION_MZONE,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_EQUIP,g,1,0,0)
end
function c978901235.eqop(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetLocationCount(tp,LOCATION_SZONE)<=0 then return end
	local c=e:GetHandler()
	local tg=Duel.GetFirstTarget()
	if tg:IsRelateToEffect(e) and Duel.IsExistingMatchingCard(c978901235.eqfilter,c:GetControler(),LOCATION_DECK,0,1,nil) then
		local tc=Duel.SelectMatchingCard(tp,c978901235.eqfilter,tp,LOCATION_DECK,0,1,1,nil):GetFirst()
		Duel.Equip(tp,tc,tg)
		--Add New Equip Limit
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_EQUIP_LIMIT)
		e1:SetProperty(EFFECT_FLAG_COPY_INHERIT+EFFECT_FLAG_OWNER_RELATE)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		e1:SetLabelObject(tg)
		e1:SetValue(c978901235.eqlimit)
		tc:RegisterEffect(e1)
	end
end
function c978901235.eqlimit(e,c)
	return e:GetLabelObject()==c
end
