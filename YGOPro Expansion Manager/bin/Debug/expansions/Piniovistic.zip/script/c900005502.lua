--Piniovistic Majistice
function c900005502.initial_effect(c)
	c:EnableReviveLimit()
	aux.AddFusionProcMix(c,true,true,aux.FilterBoolFunctionEx(Card.IsFusionSetCard,0xfdf),aux.FilterBoolFunctionEx(Card.IsRace,RACE_SPELLCASTER))
	--search
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(91258852,0))
	e1:SetCategory(CATEGORY_TOHAND+CATEGORY_SEARCH)
	e1:SetType(EFFECT_TYPE_IGNITION)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCountLimit(1)
	e1:SetTarget(c900005502.thtg)
	e1:SetOperation(c900005502.thop)
	c:RegisterEffect(e1)
	if not GhostBelleTable then GhostBelleTable={} end
	table.insert(GhostBelleTable,e1)
	--cannot be destroyed
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_SINGLE)
	e3:SetCode(EFFECT_INDESTRUCTABLE_EFFECT)
	e3:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e3:SetRange(LOCATION_MZONE)
	e3:SetCondition(c900005502.indcon)
	e3:SetValue(c900005502.indval)
	c:RegisterEffect(e3)
	--cannot target
	local e4=Effect.CreateEffect(c)
	e4:SetType(EFFECT_TYPE_SINGLE)
	e4:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCode(EFFECT_CANNOT_BE_EFFECT_TARGET)
	e4:SetCondition(c900005502.indcon)
	e4:SetValue(aux.tgoval)
	c:RegisterEffect(e4)
end
c900005502.material_setcode=0xfdf
function c900005502.thfilter1(c)
	return c:IsRace(RACE_WINDBEAST) and c:IsType(TYPE_RUNE) and c:IsAbleToHand()
end
function c900005502.thtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c900005502.thfilter1,tp,LOCATION_DECK,0,1,nil) end
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,nil,1,tp,LOCATION_DECK)
end
function c900005502.thop(e,tp,eg,ep,ev,re,r,rp)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)
	local g=Duel.SelectMatchingCard(tp,c900005502.thfilter1,tp,LOCATION_DECK,0,1,1,nil)
	if g:GetCount()>0 then
		Duel.SendtoHand(g,nil,REASON_EFFECT)
		Duel.ConfirmCards(1-tp,g)
	end
end
function c900005502.indcon(e)
	return e:GetHandler():IsSummonType(SUMMON_TYPE_FUSION)
end
function c900005502.indval(e,re,tp)
	return tp~=e:GetHandlerPlayer()
end
