--Sacrament in the Volcanic Temple
function c991028921.initial_effect(c)
	aux.AddRitualProcEqual2(c,c991028921.ritual_filter)
end
function c991028921.ritual_filter(c)
	return c:IsType(TYPE_RITUAL) and c:IsAttribute(ATTRIBUTE_FIRE)
end
