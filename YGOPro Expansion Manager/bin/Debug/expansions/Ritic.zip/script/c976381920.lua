--Dance of Waves
function c976381920.initial_effect(c)
	aux.AddRitualProcEqual2(c,c976381920.ritual_filter)
end
function c976381920.ritual_filter(c)
	return c:IsType(TYPE_RITUAL) and c:IsAttribute(ATTRIBUTE_WATER)
end
