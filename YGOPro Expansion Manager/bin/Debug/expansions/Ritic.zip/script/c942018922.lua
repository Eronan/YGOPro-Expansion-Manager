--Gust of Lights
function c942018922.initial_effect(c)
	aux.AddRitualProcEqual2(c,c942018922.ritual_filter)
end
function c942018922.ritual_filter(c)
	return c:IsType(TYPE_RITUAL) and c:IsAttribute(ATTRIBUTE_WIND) 
end
