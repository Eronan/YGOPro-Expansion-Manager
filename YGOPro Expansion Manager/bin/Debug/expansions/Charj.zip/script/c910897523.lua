--Charjing Cat
function c910897523.initial_effect(c)
	aux.EnableDualAttribute(c)
	--special summon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(14536035,0))
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_SPSUMMON_PROC)
	e1:SetProperty(EFFECT_FLAG_UNCOPYABLE)
	e1:SetRange(LOCATION_HAND)
	e1:SetCondition(c910897523.spcon)
	c:RegisterEffect(e1)
	--synchro level
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_SYNCHRO_LEVEL)
	e2:SetCondition(aux.IsDualState)
	e2:SetValue(c910897523.slevel)
	c:RegisterEffect(e2)
end
function c910897523.cfilter(c)
	return c:IsType(TYPE_DUAL)
end
function c910897523.spcon(e,c)
	if c==nil then return true end
	return Duel.GetLocationCount(c:GetControler(),LOCATION_MZONE)>0 and Duel.IsExistingMatchingCard(c910897523.cfilter,c:GetControler(),LOCATION_MZONE,0,1,nil)
end
function c910897523.slevel(e,c)
	local lv=e:GetHandler():GetLevel()
	return lv*2*65536+lv
end
