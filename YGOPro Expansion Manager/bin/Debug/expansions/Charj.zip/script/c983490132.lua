--Charjer Herza
function c983490132.initial_effect(c)
	--synchro summon
	aux.AddSynchroProcedure(c,aux.FilterBoolFunction(Card.IsRace,RACE_THUNDER),1,1,aux.NonTuner(nil),1,99)
	c:EnableReviveLimit()
	--battle indestructable
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
	e1:SetRange(LOCATION_MZONE)
	e1:SetTargetRange(LOCATION_MZONE,0)
	e1:SetTarget(c983490132.indtg)
	e1:SetValue(1)
	c:RegisterEffect(e1)
	--
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCode(EFFECT_UPDATE_ATTACK)
	e2:SetValue(c983490132.val)
	c:RegisterEffect(e2)
	--
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e3:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e3:SetCode(EVENT_SPSUMMON_SUCCESS)
	e3:SetOperation(c983490132.regop)
	e3:SetLabelObject(e2)
	c:RegisterEffect(e3)
end
function c983490132.indtg(e,c)
	return c:IsRace(RACE_THUNDER) and c~=e:GetHandler()
end
function c983490132.val(e,c)
	local ct=e:GetLabel()
	if not ct then return 0 end
	return ct
end
function c983490132.mtfilter(c)
	return bit.band(c:GetPreviousTypeOnField(),TYPE_NORMAL)~=0
end
function c983490132.regop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()	
	if c:GetSummonType()==SUMMON_TYPE_SYNCHRO then
		local ct=c:GetMaterial():Filter(c983490132.mtfilter,nil):GetCount()
		e:GetLabelObject():SetLabel(ct*500)
	end
end
