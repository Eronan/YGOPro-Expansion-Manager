--Terram Oregonite
function c908091802.initial_effect(c)
	--extra summon
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e1:SetCode(EVENT_SUMMON_SUCCESS)
	e1:SetTarget(c908091802.sumtg)
	e1:SetOperation(c908091802.sumop)
	c:RegisterEffect(e1)
	--destroy
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(80604092,0))
	e2:SetCategory(CATEGORY_DESTROY)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e2:SetCode(EVENT_PHASE+PHASE_END)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCountLimit(1)
	e2:SetCondition(c908091802.descon)
	e2:SetTarget(c908091802.destg)
	e2:SetOperation(c908091802.desop)
	c:RegisterEffect(e2)
	--Draw
	local e3=Effect.CreateEffect(c)
	e3:SetDescription(aux.Stringid(908091802,1))
	e3:SetType(EFFECT_TYPE_TRIGGER_F+EFFECT_TYPE_SINGLE)
	e3:SetProperty(EFFECT_FLAG_DAMAGE_STEP)
	e3:SetCountLimit(1,908091802+EFFECT_COUNT_CODE_OATH)
	e3:SetCode(EVENT_TO_GRAVE)
	e3:SetTarget(c908091802.drtg)
	e3:SetOperation(c908091802.drop)
	c:RegisterEffect(e3)
end
function c908091802.filter(c)
	return (c:IsSummonable(true,nil) or c:IsMSetable(true,nil)) and c:GetCode()~=908091802
end
function c908091802.sumtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then
		if not e:GetHandler():IsStatus(STATUS_CHAINING) then
			local ct=Duel.GetMatchingGroupCount(c908091802.filter,tp,LOCATION_HAND+LOCATION_MZONE,0,nil)
			return ct>0 end
	end
	Duel.SetOperationInfo(0,CATEGORY_SUMMON,nil,1,0,0)
end
function c908091802.sumop(e,tp,eg,ep,ev,re,r,rp)
	if not e:GetHandler():IsRelateToEffect(e) then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SUMMON)
	local g=Duel.SelectMatchingCard(tp,c908091802.filter,tp,LOCATION_HAND+LOCATION_MZONE,0,1,1,nil)
	local tc=g:GetFirst()
	if tc then
		--SelectPosition is currently not working.
		if tc:IsSummonable(true,nil) and tc:IsMSetable(true,nil) then
			Duel.Summon(tp,tc,true,nil)
		elseif not tc:IsSummonable(true,nil) then
			Duel.MSet(tp,tc,true,nil)
		elseif not tc:IsMSetable(true, nil) then
			Duel.Summon(tp,tc,true,nil)
		end
		
		--if tc:IsSummonable(true,nil) and (not tc:IsMSetable(true,nil) 
			--or Duel.SelectPosition(tp,tc,POS_FACEUP_ATTACK+POS_FACEDOWN_DEFENCE)==POS_FACEUP_ATTACK) then
			--Duel.Summon(tp,tc,true,nil)
		--else Duel.MSet(tp,tc,true,nil) end
	end
end
function c908091802.cfilter(c)
	return c:IsFaceup() and c:IsSetCard(0xFFC)
end
function c908091802.descon(e,tp,eg,ep,ev,re,r,rp)
	return not Duel.IsExistingMatchingCard(c908091802.cfilter,tp,LOCATION_MZONE,0,1,e:GetHandler())
end
function c908091802.destg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,e:GetHandler(),1,0,0)
end
function c908091802.desop(e,tp,eg,ep,ev,re,r,rp)
	if e:GetHandler():IsRelateToEffect(e) then
		Duel.Destroy(e:GetHandler(),REASON_EFFECT)
	end
end
function c908091802.drtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsPlayerCanDraw(tp,1) end
	Duel.SetTargetPlayer(tp)
	Duel.SetTargetParam(1)
	Duel.SetOperationInfo(0,CATEGORY_DRAW,nil,0,tp,1)
end
function c908091802.drop(e,tp,eg,ep,ev,re,r,rp)
	local p,d=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER,CHAININFO_TARGET_PARAM)
	Duel.Draw(p,d,REASON_EFFECT)
end