--Freezation Beast
local s,id=GetID()
function s.initial_effect(c)
	--Rune
	aux.AddRuneProcedure(c,s.mtfilter,1,1,s.stfilter,1,1)
	c:EnableReviveLimit()
	--back to hand
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(id,0))
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_DELAY)
	e1:SetCode(EVENT_TO_HAND)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCondition(s.zcon)
	e1:SetTarget(s.ztg)
	e1:SetOperation(s.zop)
	c:RegisterEffect(e1)
	local e2=e1:Clone()
	e2:SetCode(EVENT_TO_DECK)
	c:RegisterEffect(e2)
	--to hand
	local e3=Effect.CreateEffect(c)
	e3:SetDescription(aux.Stringid(17745969,1))
	e3:SetCategory(CATEGORY_TOHAND)
	e3:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e3:SetCode(EVENT_PHASE+PHASE_END)
	e3:SetRange(LOCATION_MZONE)
	e3:SetCountLimit(1,id+EFFECT_COUNT_CODE_OATH)
	e3:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e3:SetTarget(s.thtg)
	e3:SetOperation(s.thop)
	c:RegisterEffect(e3)
end
function s.mtfilter(c)
	return c:IsAttribute(ATTRIBUTE_WATER) and c:IsRace(RACE_ROCK)
end
function s.stfilter(c)
	return bit.band(c:GetType(),0x20004)==0x20004
end
function s.rtfilter(c,tp,loc)
	return c:IsPreviousLocation(LOCATION_ONFIELD)
		and c:GetPreviousControler()~=tp and (c:IsLocation(LOCATION_HAND) or c:IsLocation(LOCATION_EXTRA))
end
function s.zcon(e,tp,eg,ep,ev,re,r,rp)
	return eg:IsExists(s.rtfilter,1,nil,tp)
end
function s.zfilter(c,e,tp)
	if c:GetPreviousControler()==tp then return false end
	if c:IsPreviousLocation(LOCATION_MZONE) then return Duel.CheckLocation(1,LOCATION_MZONE,c:GetPreviousSequence())
	elseif c:IsPreviousLocation(LOCATION_SZONE) then return Duel.CheckLocation(1,LOCATION_SZONE,c:GetPreviousSequence()) end
end
function s.ztg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return eg:IsExists(s.zfilter,nil,e,tp) end
end
function s.zop(e,tp,eg,ep,ev,re,r,rp)
	local g=eg:Filter(s.rtfilter,nil,tp)
	local tc=g:GetFirst()
	local flag=0
	while tc do
		local nseq=tc:GetPreviousSequence()
		if tc:IsPreviousLocation(LOCATION_MZONE) then flag=flag+(2^nseq)
		elseif tc:IsPreviousLocation(LOCATION_SZONE) then flag=flag+((2^nseq)<<8) end
		tc=g:GetNext()
	end
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_DISABLE_FIELD)
	e1:SetOperation(s.disop)
	e1:SetReset(RESET_PHASE+PHASE_END)
	e1:SetLabel(flag)
	Duel.RegisterEffect(e1,1-tp)
end
function s.disop(e)
	return e:GetLabel()
end
function s.thfilter(c)
	return c:IsSetCard(0xfee) and c:IsAbleToHand()
end
function s.thtg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_GRAVE) and chkc:IsControler(tp) and s.thfilter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(s.thfilter,tp,LOCATION_GRAVE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)
	local g=Duel.SelectTarget(tp,s.thfilter,tp,LOCATION_GRAVE,0,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,g,1,0,0)
end
function s.thop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) then
		Duel.SendtoHand(tc,nil,REASON_EFFECT)
	end
end