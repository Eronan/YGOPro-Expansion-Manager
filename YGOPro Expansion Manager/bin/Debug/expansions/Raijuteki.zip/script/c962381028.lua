--Raijuteki Static
function c962381028.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(0,TIMING_END_PHASE)
	c:RegisterEffect(e1)
	--disable field
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetRange(LOCATION_SZONE)
	e2:SetCode(EFFECT_DISABLE_FIELD)
	--thanks fluo for hardcoding our day
	e2:SetCondition(function(e)if e:GetValue()~=0 then e:SetValue(c962381028.disop) end return true end)
	e2:SetValue(c962381028.disop)
	c:RegisterEffect(e2)
	--tohand
	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_TOHAND+CATEGORY_SEARCH)
	e3:SetDescription(aux.Stringid(989512332,1))
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e3:SetCode(EVENT_BE_MATERIAL)
	e3:SetCountLimit(1,962381028+EFFECT_COUNT_CODE_OATH)
	e3:SetCondition(c962381028.thcon)
	e3:SetTarget(c962381028.thtg)
	e3:SetOperation(c962381028.thop)
	c:RegisterEffect(e3)
end
function c962381028.disop(e)
	local c=e:GetHandler()
	local seq=c:GetSequence()
	local nseq=4-seq
	if c:GetControler()==1 then seq,nseq=nseq,seq end
	local flag=0
	if Duel.CheckLocation(0,LOCATION_MZONE,seq) then flag=flag+(2^seq) end
	if Duel.CheckLocation(0,LOCATION_SZONE,seq) then flag=flag+((2^seq)<<8) end
	if Duel.CheckLocation(1,LOCATION_MZONE,nseq) then flag=flag+((2^nseq)<<16) end
	if Duel.CheckLocation(1,LOCATION_SZONE,nseq) then flag=flag+((2^nseq)<<24) end
	if seq==1 and Duel.CheckLocation(0,LOCATION_MZONE,5) then flag=flag+(2^5) end
	if seq==3 and Duel.CheckLocation(0,LOCATION_MZONE,6) then flag=flag+(2^6) end
	return flag
end
function c962381028.thcon(e,tp,eg,ep,ev,re,r,rp)
	local rc=e:GetHandler():GetReasonCard()
	return r==REASON_SPSUMMON and rc:GetSummonType()==SUMMON_TYPE_RUNE and rc:IsSetCard(0xffa)
end
function c962381028.thfilter(c)
	return c:IsType(TYPE_MONSTER) and c:IsSetCard(0xffa) and c:IsAbleToHand()
end
function c962381028.thtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c962381028.thfilter,tp,LOCATION_DECK,0,1,nil,tp) end
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,nil,1,tp,LOCATION_DECK)
end
function c962381028.thop(e,tp,eg,ep,ev,re,r,rp)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)
	local sg=Duel.SelectMatchingCard(tp,c962381028.thfilter,tp,LOCATION_DECK,0,1,1,nil)
	if sg:GetCount()>0 then
		Duel.SendtoHand(sg,nil,REASON_EFFECT)
		Duel.ConfirmCards(1-tp,sg)
	end
end
