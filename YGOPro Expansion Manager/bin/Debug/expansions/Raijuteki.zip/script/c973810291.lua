--Raijuteki Stream
function c973810291.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	c:RegisterEffect(e1)
	--atk up
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetCode(EFFECT_SET_BASE_ATTACK)
	e2:SetRange(LOCATION_SZONE)
	e2:SetTargetRange(LOCATION_MZONE,0)
	e2:SetTarget(c973810291.atktg)
	e2:SetValue(2500)
	c:RegisterEffect(e2)
	e1:SetLabelObject(e2)
	--destroy
	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_DESTROY)
	e3:SetDescription(aux.Stringid(989512332,1))
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e3:SetCode(EVENT_BE_MATERIAL)
	e3:SetCountLimit(1,973810291+EFFECT_COUNT_CODE_OATH)
	e3:SetCondition(c973810291.descon)
	e3:SetTarget(c973810291.destg)
	e3:SetOperation(c973810291.desop)
	c:RegisterEffect(e3)
end
function c973810291.atktg(e,c)
	return c:IsSetCard(0xffa) and c:IsType(TYPE_RUNE) and c:IsSummonType(SUMMON_TYPE_RUNE)
end
function c973810291.descon(e,tp,eg,ep,ev,re,r,rp)
	local rc=e:GetHandler():GetReasonCard()
	return r==REASON_SPSUMMON and rc:GetSummonType()==SUMMON_TYPE_RUNE and rc:IsSetCard(0xffa)
end
function c973810291.destg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetFlagEffect(tp,973810291)==0 and Duel.IsExistingTarget(Card.IsDefensePos,tp,LOCATION_MZONE,0,1,nil) end
	Duel.RegisterFlagEffect(tp,973810291,RESET_PHASE+PHASE_END,0,1)
	local g=Duel.GetMatchingGroup(Card.IsDefensePos,tp,0,LOCATION_MZONE,nil)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,g:GetCount(),0,0)
end
function c973810291.desop(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetMatchingGroup(Card.IsDefensePos,tp,0,LOCATION_MZONE,nil)
	Duel.Destroy(g,REASON_EFFECT)
end
