--Raijuteki Summoning Storm
function c953820192.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(0,TIMING_END_PHASE)
	e1:SetTarget(c953820192.target)
	c:RegisterEffect(e1)
	--special summon
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(35125879,0))
	e2:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetCode(EVENT_FREE_CHAIN)
	e2:SetHintTiming(0,TIMING_END_PHASE)
	e2:SetRange(LOCATION_SZONE)
	e2:SetCost(c953820192.cost)
	e2:SetTarget(c953820192.runtg)
	e2:SetOperation(c953820192.runop)
	c:RegisterEffect(e2)
	--destroy
	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_TOHAND)
	e3:SetDescription(aux.Stringid(989512332,1))
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e3:SetCode(EVENT_BE_MATERIAL)
	e3:SetCost(c953820192.cost)
	e3:SetCondition(c953820192.thcon)
	e3:SetTarget(c953820192.thtg)
	e3:SetOperation(c953820192.thop)
	c:RegisterEffect(e3)
end
function c953820192.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetFlagEffect(tp,953820192)==0 end
	Duel.RegisterFlagEffect(tp,953820192,RESET_PHASE+PHASE_END,0,1)
end
function c953820192.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return c953820192.runtg(e,tp,eg,ep,ev,re,r,rp,chk,chkc) end
	if chk==0 then return true end
	local b1=c953820192.cost(e,tp,eg,ep,ev,re,r,rp,0)
		and c953820192.runtg(e,tp,eg,ep,ev,re,r,rp,0)
	if b1 and Duel.SelectYesNo(tp,94) then
		e:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_TOGRAVE)
		e:SetProperty(EFFECT_FLAG_CARD_TARGET)
		e:SetOperation(c953820192.runop)
		c953820192.cost(e,tp,eg,ep,ev,re,r,rp,chk)
		c953820192.runtg(e,tp,eg,ep,ev,re,r,rp,1)		
	else
		e:SetCategory(0)
		e:SetProperty(0)
		e:SetOperation(nil)
	end
end
function c953820192.runfilter(c,e)
	return c:IsSetCard(0xffa) and c:IsRuneSummonable(e,nil,nil,e:GetHandler())
end
function c953820192.runtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c953820192.runfilter,tp,0x3ff~LOCATION_MZONE,0,1,nil,e) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,0x3ff~LOCATION_MZONE)
end
function c953820192.runop(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetMatchingGroup(c953820192.runfilter,tp,0x3ff~LOCATION_MZONE,0,nil,e)
	if g:GetCount()>0 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local tg=g:Select(tp,1,1,nil)
		local sc=tg:GetFirst()
		--Set Parameters
		local f1,min1,max1,f2,min2,max2
		if (not sc.ex_rune_parameters and sc:IsLocation(sc.altRuneLoc)) or sc:IsLocation(LOCATION_HAND) then
			f1=sc.rune_parameters[1]
			min1=sc.rune_parameters[2]
			max1=sc.rune_parameters[3]
			f2=sc.rune_parameters[4]
			min2=sc.rune_parameters[5]
			max2=sc.rune_parameters[6]
		elseif sc:IsLocation(sc.altRuneLoc) then
			f1=sc.ex_rune_parameters[1]
			min1=sc.ex_rune_parameters[2]
			max1=sc.ex_rune_parameters[3]
			f2=sc.ex_rune_parameters[4]
			min2=sc.ex_rune_parameters[5]
			max2=sc.ex_rune_parameters[6]
		end
		local exChk=(sc.altRuneLoc==LOCATION_EXTRA)
		local alterG=sc.altG
		--Rune Summon
		aux.RunTarget(f1,min1,max1,f2,min2,max2,exChk,alterG,e:GetHandler())(e,tp,eg,ep,ev,re,r,rp,chk,sc)
		aux.RunOperation(e,tp,eg,ep,ev,re,r,rp,sc,smat,mg)
		Duel.SpecialSummon(sc,SUMMON_TYPE_RUNE,tp,tp,false,true,POS_FACEUP)
	end
end
function c953820192.thcon(e,tp,eg,ep,ev,re,r,rp)
	local rc=e:GetHandler():GetReasonCard()
	return r==REASON_SPSUMMON and rc:GetSummonType()==SUMMON_TYPE_RUNE and rc:IsSetCard(0xffa)
end
function c953820192.tgfilter(c)
	return c:IsType(TYPE_MONSTER) and c:IsSetCard(0xffa) and c:IsAbleToHand()
end
function c953820192.thtg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_GRAVE) and chkc:IsControler(tp) and c953820192.tgfilter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c953820192.tgfilter,tp,LOCATION_GRAVE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)
	local sg=Duel.SelectTarget(tp,c953820192.tgfilter,tp,LOCATION_GRAVE,0,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,sg,sg:GetCount(),0,0)
end
function c953820192.thop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc and tc:IsRelateToEffect(e) then
		Duel.SendtoHand(tc,nil,REASON_EFFECT)
	end
end
