--Raijuteki Great Mother
function c993710291.initial_effect(c)
	--Rune Summon
	c:EnableReviveLimit()
	aux.AddRuneProcedure(c,aux.FilterBoolFunction(Card.IsType,TYPE_RUNE),1,99,c993710291.STRunFilter,2,99)
	--mat check
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_MATERIAL_CHECK)
	e1:SetValue(c993710291.valcheck)
	c:RegisterEffect(e1)
	--set
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(494922,0))
	e2:SetType(EFFECT_TYPE_IGNITION)
	e2:SetCode(EVENT_FREE_CHAIN)
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetRange(LOCATION_MZONE)
	e2:SetLabelObject(e1)
	e2:SetCountLimit(1)
	e2:SetCondition(c993710291.setcon)
	e2:SetTarget(c993710291.settg)
	e2:SetOperation(c993710291.setop)
	c:RegisterEffect(e2)
	--immune
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_SINGLE)
	e3:SetCode(EFFECT_IMMUNE_EFFECT)
	e3:SetLabelObject(e1)
	e3:SetCondition(c993710291.immcon)
	e3:SetValue(c993710291.efilter)
	c:RegisterEffect(e3)
	--cannot be target
	local e4=Effect.CreateEffect(c)
	e4:SetType(EFFECT_TYPE_FIELD)
	e4:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE)
	e4:SetCode(EFFECT_CANNOT_BE_EFFECT_TARGET)
	e4:SetRange(LOCATION_MZONE)
	e4:SetLabelObject(e1)
	e4:SetTargetRange(LOCATION_MZONE,0)
	e4:SetCondition(c993710291.tgcon)
	e4:SetTarget(c993710291.tgtg)
	e4:SetValue(aux.tgoval)
	c:RegisterEffect(e4)
end
function c993710291.STRunFilter(c)
	return c:IsSetCard(0xffa) and c:IsType(TYPE_TRAP)
end
function c993710291.valcheck(e,c)
	local ct=e:GetHandler():GetMaterial():GetClassCount(Card.GetCode)
	e:SetLabel(ct)
end
function c993710291.setcon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetLabelObject():GetLabel()>=4
end
function c993710291.setfilter(c,tp)
	return c:IsSetCard(0xffa) and c:IsType(TYPE_TRAP) and c:IsSSetable(true)
end
function c993710291.settg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsControler(tp) and chkc:IsLocation(LOCATION_GRAVE) and c993710291.setfilter(chkc,tp) end
	if chk==0 then return Duel.IsExistingTarget(c993710291.setfilter,tp,LOCATION_GRAVE,0,1,nil,tp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SET)
	local g=Duel.SelectTarget(tp,c993710291.setfilter,tp,LOCATION_GRAVE,0,1,1,nil,tp)
	Duel.SetOperationInfo(0,CATEGORY_LEAVE_GRAVE,g,1,0,0)
end
function c993710291.setop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) and (tc:IsType(TYPE_FIELD) or Duel.GetLocationCount(tp,LOCATION_SZONE)>0) then
		Duel.SSet(tp,tc)
		Duel.ConfirmCards(1-tp,tc)
	end
end
function c993710291.immcon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetLabelObject():GetLabel()>=5
end
function c993710291.efilter(e,re)
	return e:GetHandlerPlayer()~=re:GetOwnerPlayer()
end
function c993710291.tgcon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetLabelObject():GetLabel()>=6
end
function c993710291.tgtg(e,c)
	return c~=e:GetHandler() and c:IsSetCard(0xffa)
end

