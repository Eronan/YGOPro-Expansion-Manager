--Reguraptor Fortress
function c905831981.initial_effect(c)
	--activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(0,TIMING_END_PHASE+0x1c0)
	e1:SetTarget(c905831981.sctg1)
	e1:SetOperation(c905831981.scop)
	c:RegisterEffect(e1)
	--cannot select, except link thing
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetRange(LOCATION_SZONE)
	e2:SetTargetRange(0,LOCATION_MZONE)
	e2:SetCode(EFFECT_CANNOT_SELECT_BATTLE_TARGET)
	e2:SetCondition(c905831981.tgcondition)
	e2:SetValue(c905831981.atlimit)
	c:RegisterEffect(e2)
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CANNOT_BE_EFFECT_TARGET)
	e3:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_SET_AVAILABLE)
	e3:SetRange(LOCATION_SZONE)
	e3:SetTargetRange(LOCATION_MZONE,0)
	e3:SetCondition(c905831981.tgcondition)
	e3:SetTarget(c905831981.atlimit)
	e3:SetValue(aux.tgoval)
	c:RegisterEffect(e3)
	--synchro effect
	local e4=Effect.CreateEffect(c)
	e4:SetDescription(aux.Stringid(3580032,0))
	e4:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e4:SetType(EFFECT_TYPE_QUICK_O)
	e4:SetCode(EVENT_FREE_CHAIN)
	e4:SetRange(LOCATION_SZONE)
	e4:SetCountLimit(1)
	e4:SetHintTiming(0,TIMING_END_PHASE+0x1c0)
	e4:SetCondition(c905831981.sccon)
	e4:SetTarget(c905831981.sctg2)
	e4:SetOperation(c905831981.scop)
	c:RegisterEffect(e4)
end
function c905831981.filter(c)
	return c:IsFaceup() and c:GetSequence()>=5
end
function c905831981.tgcondition(e,c)
	return Duel.IsExistingMatchingCard(c905831981.filter,e:GetHandler():GetControler(),LOCATION_MZONE,0,1,nil)
end
function c905831981.atlimit(e,c)
	return c:GetSequence()<5
end
function c905831981.sccon(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetTurnPlayer()~=tp and e:GetHandler():GetFlagEffect(905831981)==0
end
function c905831981.scfilter(c)
	return c:IsSetCard(0xffb) and c:IsSynchroSummonable(nil)
end
function c905831981.sctg1(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	if c905831981.sccon(e,tp,eg,ep,ev,re,r,rp)
		and Duel.IsExistingMatchingCard(c905831981.scfilter,tp,LOCATION_EXTRA,0,1,nil)
		and Duel.SelectYesNo(tp,94) then
		e:GetHandler():RegisterFlagEffect(905831981,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END,0,1)
		e:GetHandler():RegisterFlagEffect(0,RESET_CHAIN,EFFECT_FLAG_CLIENT_HINT,1,0,65)
		Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
	end
end
function c905831981.sctg2(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c905831981.scfilter,tp,LOCATION_EXTRA,0,1,nil) end
	e:GetHandler():RegisterFlagEffect(905831981,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END,0,1)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
end
function c905831981.scop(e,tp,eg,ep,ev,re,r,rp)
	if e:GetHandler():GetFlagEffect(905831981)==0 or not e:GetHandler():IsRelateToEffect(e) then return end
	local g=Duel.GetMatchingGroup(c905831981.scfilter,tp,LOCATION_EXTRA,0,nil)
	if g:GetCount()>0 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local sg=g:Select(tp,1,1,nil)
		Duel.SynchroSummon(tp,sg:GetFirst(),nil)
	end
end
