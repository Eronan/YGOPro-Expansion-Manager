--Sky Guardian Brezan
function c991138192.initial_effect(c)
	c:EnableReviveLimit()
	aux.AddSynchroProcedure(c,nil,2,99,aux.NonTuner(nil),1,1)
	c:SetSPSummonOnce(991138192)
	--destroy
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(31766317,1))
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCountLimit(1)
	e1:SetCost(c991138192.spcost)
	e1:SetTarget(c991138192.sptg)
	e1:SetOperation(c991138192.spop)
	c:RegisterEffect(e1)
	--cannot be target
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE)
	e2:SetCode(EFFECT_CANNOT_BE_EFFECT_TARGET)
	e2:SetRange(LOCATION_MZONE)
	e2:SetTargetRange(LOCATION_MZONE,0)
	e2:SetTarget(c991138192.tgtg)
	e2:SetValue(aux.tgoval)
	c:RegisterEffect(e2)
end
function c991138192.cfilter(c)
	return not c:IsStatus(STATUS_BATTLE_DESTROYED)
end
function c991138192.spcost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.CheckReleaseGroupCost(tp,c991138192.cfilter,1,false,nil,nil) end
	local g=Duel.SelectReleaseGroupCost(tp,c991138192.cfilter,1,1,false,nil,nil)
	Duel.Release(g,REASON_COST)
end
function c991138192.spfilter(c,e,tp)
	return c:IsRace(RACE_WINGEDBEAST) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsCode(991138192)
end
function c991138192.sptg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsControler(tp) and chkc:IsLocation(LOCATION_GRAVE) and c991138192.filter(chkc,e,tp) end
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and Duel.IsExistingTarget(c991138192.filter,tp,LOCATION_GRAVE,0,1,nil,e,tp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectTarget(tp,c991138192.filter,tp,LOCATION_GRAVE,0,1,1,nil,e,tp)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,g,1,0,0)
end
function c991138192.spop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc and tc:IsRelateToEffect(e) then
		Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP)
	end
end
function c991138192.tgtg(e,c)
	return c~=e:GetHandler()
end
