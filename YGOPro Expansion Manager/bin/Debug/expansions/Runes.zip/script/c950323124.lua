--Sentry Dog
function c950323124.initial_effect(c)
	--Rune Summon
	c:EnableReviveLimit()
	aux.AddRuneProcedure(c,aux.FilterBoolFunction(Card.IsCode,86889202),1,1,c950323124.STMatFilter,1,1)
	--multi attack
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_EXTRA_ATTACK)
	e1:SetRange(LOCATION_MZONE)
	e1:SetValue(c950323124.val)
	c:RegisterEffect(e1)
	--atkup
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(950323124,0))
	e2:SetCategory(CATEGORY_ATKCHANGE)
	e2:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_F)
	e2:SetCode(EVENT_BATTLE_DAMAGE)
	e2:SetCondition(c950323124.atkcon)
	e2:SetOperation(c950323124.atkop)
	c:RegisterEffect(e2)
end
function c950323124.STMatFilter(c)
	return bit.band(c:GetType(),0x20002)==0x20002
end
function c950323124.atkfilter(c)
	return c:IsFaceup() and c:IsType(TYPE_SPELL+TYPE_TRAP)
end
function c950323124.val(e,c)
	return Duel.GetMatchingGroupCount(c950323124.atkfilter,c:GetControler(),LOCATION_ONFIELD,0,nil)-1
end
function c950323124.atkcon(e,tp,eg,ep,ev,re,r,rp)
	return ep~=tp
end
function c950323124.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if c:IsFacedown() or not c:IsRelateToEffect(e) then return end
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_UPDATE_ATTACK)
	e1:SetValue(200)
	e1:SetReset(RESET_EVENT+0x1ff0000)
	c:RegisterEffect(e1)
end
