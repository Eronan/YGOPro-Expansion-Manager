--Dark Sorcerer
function c938291023.initial_effect(c)
	--Rune Summon
	c:EnableReviveLimit()
	aux.AddRuneProcedure(c,aux.NOT(aux.FilterBoolFunction(Card.IsType,TYPE_EFFECT)),1,1,nil,1,1,LOCATION_PZONE)
	aux.EnablePendulumAttribute(c)
end
