--Magician Girl of Black Chaos
function c930208479.initial_effect(c)
	--Rune Summon
	c:EnableReviveLimit()
	aux.AddRuneProcedure(c,aux.FilterBoolFunction(Card.IsRace,RACE_SPELLCASTER),1,1,c930208479.STFilter,1,1)
	--Eye of Timaeus
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(40884383,0))
	e1:SetCategory(CATEGORY_EQUIP+CATEGORY_SEARCH)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetCondition(c930208479.thcon)
	e1:SetTarget(c930208479.thtg)
	e1:SetOperation(c930208479.thop)
	c:RegisterEffect(e1)
	--Gain ATK
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_SINGLE)
	e3:SetRange(LOCATION_MZONE)
	e3:SetCode(EFFECT_UPDATE_ATTACK)
	e3:SetValue(c930208479.atkval)
	c:RegisterEffect(e3)
end
function c930208479.STFilter(c)
    return aux.IsCodeListed(c,46986414) or aux.IsCodeListed(c,38033121)
end
function c930208479.thfilter(c)
    return c:IsCode(1784686) and c:IsAbleToHand()
end
function c930208479.thcon(e,c)
	return e:GetHandler():GetSummonType()==SUMMON_TYPE_RUNE
end
function c930208479.thtg(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then return Duel.IsExistingMatchingCard(c930208479.thfilter,tp,LOCATION_DECK,0,1,nil) end
    Duel.SetOperationInfo(0,CATEGORY_TOHAND,nil,1,tp,LOCATION_DECK)
end
function c930208479.thop(e,tp,eg,ep,ev,re,r,rp)
    if not e:GetHandler():IsRelateToEffect(e) then return end
    Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)
    local g=Duel.SelectMatchingCard(tp,c930208479.thfilter,tp,LOCATION_DECK,0,1,1,nil)
    if g:GetCount()>0 then
        Duel.SendtoHand(g,nil,REASON_EFFECT)
        Duel.ConfirmCards(1-tp,g)
    end
end
function c930208479.atkfilter(c)
	return c:IsFaceup() and (aux.IsCodeListed(c,46986414) or aux.IsCodeListed(c,38033121))
end
function c930208479.atkval(e,c)
	return Duel.GetMatchingGroupCount(c930208479.atkfilter,c:GetControler(),LOCATION_ONFIELD,LOCATION_ONFIELD,nil)*300
end
