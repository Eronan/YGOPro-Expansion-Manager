--Hydranic Lord - Daedalus Zenith
function c962318972.initial_effect(c)
	--Rune Summon
	c:EnableReviveLimit()
	aux.AddRuneProcedure(c,aux.FilterBoolFunction(Card.IsAttribute,ATTRIBUTE_WATER),1,1,aux.FilterBoolFunction(Card.IsCode,22702055),1,99)
	--atkup
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetRange(LOCATION_MZONE)
	e2:SetTargetRange(LOCATION_MZONE,0)
	e2:SetCode(EFFECT_ADD_CODE)
	e2:SetTarget(c962318972.cdtg)
	e2:SetValue(22702055)
	c:RegisterEffect(e2)
	--
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_SINGLE)
	e3:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e3:SetRange(LOCATION_MZONE)
	e3:SetCode(EFFECT_INDESTRUCTABLE_COUNT)
	e3:SetCountLimit(c962318972.desval)
	e3:SetValue(c962318972.valcon)
	c:RegisterEffect(e3)
	--
	local e4=Effect.CreateEffect(c)
	e4:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e4:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e4:SetCode(EVENT_SPSUMMON_SUCCESS)
	e4:SetLabelObject(e3)
	e4:SetOperation(c962318972.regop)
	c:RegisterEffect(e4)
end
function c962318972.cdtg(e,c)
	return c:IsAttribute(ATTRIBUTE_WATER) and c~=e:GetHandler()
end
function c962318972.desval(e)
	return e:GetLabel()
end
function c962318972.valcon(e,re,r,rp)
	return bit.band(r,REASON_BATTLE+REASON_EFFECT)~=0
end
function c962318972.regop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if c:GetSummonType()==SUMMON_TYPE_RUNE then
		local ct=c:GetMaterialCount()-1
		e:GetLabelObject():SetLabel(ct)
	end
end
