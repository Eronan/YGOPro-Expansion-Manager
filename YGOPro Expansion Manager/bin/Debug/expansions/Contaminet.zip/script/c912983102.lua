--Contaminet Keylogger
function c912983102.initial_effect(c)
	--Rune Summon
	c:EnableReviveLimit()
	aux.AddRuneProcedure(c,aux.FilterBoolFunction(Card.IsSetCard,0x1fe7),1,1,nil,1,nil,nil,c912983102.getGroup)
	--Replace Effect
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(41209827,1))
	e2:SetType(EFFECT_TYPE_IGNITION)
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCountLimit(1)
	e2:SetTarget(c912983102.copytg)
	e2:SetOperation(c912983102.copyop)
	c:RegisterEffect(e2)
end
function c912983102.rune_filter(c,tp)
	return c:IsFaceup() and ((c:IsType(TYPE_SPELL+TYPE_TRAP) and c:IsControler(tp)) or c:IsType(TYPE_MONSTER))
end
function c912983102.getGroup(tp,ex)
	return Duel.GetMatchingGroup(c912983102.rune_filter,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,ex,tp)
end
function c912983102.copyfilter(c)
	return c:IsFaceup() and c:IsSetCard(0x1fe7)
end
function c912983102.copytg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsControler(1-tp) and chkc:IsLocation(LOCATION_ONFIELD) and c912983102.copyfilter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c912983102.copyfilter,tp,0,LOCATION_ONFIELD,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	Duel.SelectTarget(tp,c912983102.copyfilter,tp,0,LOCATION_ONFIELD,1,1,nil)
end
function c912983102.copyop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if tc and c:IsRelateToEffect(e) and c:IsFaceup() and tc:IsRelateToEffect(e) and tc:IsFaceup() and not tc:IsType(TYPE_TOKEN) then
		local code=tc:GetOriginalCodeRule()
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
		e1:SetCode(EFFECT_CHANGE_CODE)
		e1:SetValue(code)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		c:RegisterEffect(e1)
		if not tc:IsType(TYPE_TRAPMONSTER) then
			c:CopyEffect(code,RESET_EVENT+0x1fe0000,1)
		end
	end
end
