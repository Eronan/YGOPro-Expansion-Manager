--Contaminet Trojan
function c971890532.initial_effect(c)
	--Rune Summon
	c:EnableReviveLimit()
	aux.AddRuneProcedure(c,aux.FilterBoolFunction(Card.IsSetCard,0x1fe7),2,2,aux.FilterBoolFunction(Card.IsCode,912389041),1,nil,nil,c971890532.getGroup)
	--disable zone
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(53244294,1))
	e1:SetType(EFFECT_TYPE_IGNITION)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCondition(c971890532.zcon)
	e1:SetTarget(c971890532.ztg)
	e1:SetOperation(c971890532.zop)
	e1:SetLabel(0)
	c:RegisterEffect(e1)
end
function c971890532.getGroup(tp,ex)
	return Duel.GetMatchingGroup(Card.IsFaceup,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,ex)
end
function c971890532.zfilter(c)
	--Face-up "Contaminet-" card or face-down monster
	if c:IsFaceup() then return c:IsSetCard(0x1fe7)
	else return c:IsLocation(LOCATION_MZONE) end
end
function c971890532.zcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	return Duel.GetMatchingGroupCount(c971890532.zfilter,c:GetControler(),0,LOCATION_ONFIELD,nil)>e:GetLabel()
end
function c971890532.ztg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(1-tp,LOCATION_MZONE)+Duel.GetLocationCount(1-tp,LOCATION_SZONE)>0 end
	local dis=Duel.SelectDisableField(tp,1,0,LOCATION_ONFIELD,0)
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetLabel(dis)
	e:SetLabelObject(e1)
end
function c971890532.zop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local e1=e:GetLabelObject()
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCode(EFFECT_DISABLE_FIELD)
	e1:SetOperation(c971890532.disop)
	e1:SetReset(RESET_EVENT+0x1ff0000)
	c:RegisterEffect(e1)
	e:SetLabel(e:GetLabel()+1)
end
function c971890532.disop(e,tp)
	return e:GetLabel()
end
