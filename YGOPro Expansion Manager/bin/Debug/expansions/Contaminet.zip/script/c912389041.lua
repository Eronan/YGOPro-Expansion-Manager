--Contaminetwork
function c912389041.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	c:RegisterEffect(e1)
	--extra summon
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetCode(EFFECT_EXTRA_SUMMON_COUNT)
	e2:SetRange(LOCATION_FZONE)
	e2:SetTargetRange(LOCATION_HAND+LOCATION_MZONE,0)
	e2:SetTarget(aux.TargetBoolFunction(Card.IsSetCard,0x1fe7))
	c:RegisterEffect(e2)
	--immune effect
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_IMMUNE_EFFECT)
	e3:SetRange(LOCATION_FZONE)
	e3:SetTargetRange(0,LOCATION_MZONE)
	e3:SetTarget(c912389041.etarget)
	e3:SetValue(c912389041.efilter)
	c:RegisterEffect(e3)
	--Search
	local e4=Effect.CreateEffect(c)
	e4:SetCategory(CATEGORY_TOHAND+CATEGORY_SEARCH)
	e4:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e4:SetCode(EVENT_TO_GRAVE)
	e4:SetRange(LOCATION_SZONE)
	e4:SetCountLimit(1,912389041+EFFECT_COUNT_CODE_OATH)
	e4:SetCondition(c912389041.ctcon)
	e4:SetTarget(c912389041.cttg)
	e4:SetOperation(c912389041.ctop)
	c:RegisterEffect(e4)
end
function c912389041.etarget(e,c)
	return c:IsSetCard(0x1fe7)
end
function c912389041.efilter(e,re)
	return re:GetOwnerPlayer()~=e:GetHandlerPlayer()
end
function c912389041.ctcfilter(c,tp)
	return c:IsPreviousSetCard(0x1fe7) and c:IsPreviousLocation(LOCATION_ONFIELD)
		and c:IsReason(0x100000000) and c:GetReasonCard():IsSetCard(0x1fe7)
end
function c912389041.ctcon(e,tp,eg,ep,ev,re,r,rp)
	return eg:IsExists(c912389041.ctcfilter,1,nil,tp)
end
function c912389041.ctfilter(c)
	return c:IsSetCard(0x1fe7) and c:IsControlerCanBeChanged()
end
function c912389041.cttg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(1-tp) and c912389041.ctfilter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c912389041.ctfilter,tp,0,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_CONTROL)
	local g=Duel.SelectTarget(tp,c912389041.ctfilter,tp,0,LOCATION_MZONE,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_CONTROL,g,1,0,0)
end
function c912389041.ctop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) and tc:IsFaceup() then
		Duel.GetControl(tc,tp)
	end
end
