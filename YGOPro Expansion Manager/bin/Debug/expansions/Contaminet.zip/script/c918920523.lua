--Contaminet Ransomware
function c918920523.initial_effect(c)
	--Rune Summon
	c:EnableReviveLimit()
	aux.AddRuneProcedure(c,aux.FilterBoolFunction(Card.IsSetCard,0x1fe7),1,1,aux.FilterBoolFunction(Card.IsCode,912389041),1,nil,nil,c918920523.getGroup)
	--destroy
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(15187079,0))
	e1:SetCategory(CATEGORY_CONTROL)
	e1:SetType(EFFECT_TYPE_IGNITION)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCountLimit(1)
	e1:SetTarget(c918920523.cttg)
	e1:SetOperation(c918920523.ctop)
	c:RegisterEffect(e1)
end
function c918920523.getGroup(tp,ex)
	return Duel.GetMatchingGroup(Card.IsFaceup,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,ex)
end
function c918920523.filter(c)
	return c:IsFaceup() and c:IsSetCard(0x1fe7) and c:IsAbleToChangeControler()
end
function c918920523.cttg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(1-tp) and c918920523.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c918920523.filter,tp,0,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_CONTROL)
	local g=Duel.SelectTarget(tp,c918920523.filter,tp,0,LOCATION_MZONE,1,1,nil)
	if Duel.GetLP(1-tp)>1500 then
		Duel.SetOperationInfo(0,CATEGORY_CONTROL,g,1,0,0)
	end
end
function c918920523.ctop(e,tp,eg,ep,ev,re,r,rp)
	if Duel.CheckLPCost(1-tp,1500) and Duel.SelectYesNo(1-tp,aux.Stringid(80764541,1)) then
		Duel.PayLPCost(1-tp,1500)
		if Duel.IsChainDisablable(0) then
			Duel.NegateEffect(0)
			return
		end
	end
	local tc=Duel.GetFirstTarget()
	if tc:IsFaceup() and tc:IsRelateToEffect(e) then
		Duel.GetControl(tc,tp)
	end
end
